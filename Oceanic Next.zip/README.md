# Oceanic Next for Netbeans IDE
> A color scheme for [Netbeans IDE](https://netbeans.org) based on [voronianski's Oceanic Next](https://github.com/voronianski/oceanic-next-color-scheme).

# Installation
Download the zip file (don't unzip). Then select it from `Preferences` `->` `Fonts & Colors` `->` `Import`.

# Screenshot
![Screenshot](screenshot.png)

---

**MIT Licensed**
